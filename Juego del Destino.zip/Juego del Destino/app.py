from flask import Flask, render_template, request, session, redirect, url_for
import random

app = Flask(__name__)
app.secret_key = "secret_key_dojo_adivino"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/enviar', methods=['POST'])
def enviar():
    # Capturar datos del formulario
    session['nombre'] = request.form['nombre']
    session['lugar'] = request.form['lugar']
    session['numero'] = request.form['numero']
    session['comida'] = request.form['comida']
    session['profesion'] = request.form['profesion']

    # Redirigir a la página del futuro
    return redirect(url_for('futuro'))

@app.route('/futuro')
def futuro():
    # Recuperar los datos de sesión
    nombre = session.get('nombre')
    lugar = session.get('lugar')
    numero = session.get('numero')
    comida = session.get('comida')
    profesion = session.get('profesion')

    # Elegir aleatoriamente entre dos mensajes
    if random.choice([True, False]):
        mensaje = f"Soy el adivino del Dojo, {nombre} tendrá un viaje muy largo dentro de {numero} años a {lugar} y estará el resto de sus días preparando {comida} para todas las personas que quiere. Cambió de profesión y ahora es {profesion}."
    else:
        mensaje = f"Soy el adivino del Dojo, {nombre} tendrá {numero} años de mala suerte, nunca conocerá {lugar} y jamás volvió a comer {comida}. Cambió de profesión y ahora es {profesion}."

    return render_template('futuro.html', mensaje=mensaje)

if __name__ == '__main__':
    app.run(debug=True)
