from flask import Flask, render_template

app = Flask(__name__)

@app.route('/loteria')
def loteria():
    # Tablero fijo 4x4
    colores = ["#287fe4", "#eadb00", "#dda8c4", "#287fe4", "#eadb00", "#dda8c4", "#287fe4", "#eadb00"]
    return render_template("index.html", filas=4, columnas=4, colores=colores)

@app.route('/<int:x>')
def tablero_personalizado(x):
    # Tablero de 4 columnas y x filas
    colores = ["#287fe4", "#eadb00", "#dda8c4"]
    return render_template("index.html", filas=x, columnas=4, colores=colores)

if __name__ == "__main__":
    app.run(debug=True)
