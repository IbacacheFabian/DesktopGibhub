from flask import Flask, render_template
import random

app = Flask(__name__)

@app.route('/loteria')
def loteria():
    # Definir los colores en hexadecimal
    colores = ["#287fe4", "#eadb00", "#dda8c4"]
    
    # Crear un tablero de 4x4 con colores aleatorios
    tablero = [[random.choice(colores) for _ in range(4)] for _ in range(4)]
    
    return render_template("index.html", tablero=tablero)

if __name__ == "__main__":
    app.run(debug=True)
