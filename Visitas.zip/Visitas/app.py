from flask import Flask, session, redirect, url_for, render_template, request

app = Flask(__name__)
app.secret_key = 'secreto_seguro_para_flask'

@app.route('/')
def index():
    # Inicializar visitas y reinicios si no existen en la sesión
    if 'visitas' not in session:
        session['visitas'] = 0
    if 'reinicios' not in session:
        session['reinicios'] = 0

    return render_template('index.html', visitas=session['visitas'], reinicios=session['reinicios'])

@app.route('/incrementar', methods=['POST'])
def incrementar():
    cantidad = int(request.form.get('cantidad', 1))  # Si no hay cantidad, usa 1 por defecto
    session['visitas'] = session.get('visitas', 0) + cantidad
    return redirect(url_for('index'))

@app.route('/reiniciar', methods=['POST'])
def reiniciar():
    session['visitas'] = 0
    session['reinicios'] = session.get('reinicios', 0) + 1
    return redirect(url_for('index'))

@app.route('/destruir_sesion')
def destruir_sesion():
    session.clear()  # Borra toda la sesión
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
