from flask_app.config.mysqlconnection import connectToMySQL

class Estudiante:
    db = "esquema_estudiantes_cursos"

    @classmethod
    def guardar(cls, data):
        query = """
        INSERT INTO estudiantes (nombre, apellido, edad, curso_id) 
        VALUES (%(nombre)s, %(apellido)s, %(edad)s, %(curso_id)s);
        """
        return connectToMySQL(cls.db).query_db(query, data)

    @classmethod
    def obtener_por_curso(cls, curso_id):
        query = "SELECT * FROM estudiantes WHERE curso_id = %(curso_id)s;"
        return connectToMySQL(cls.db).query_db(query, {'curso_id': curso_id})

    @staticmethod
    def guardar(data):
        query = """
        INSERT INTO estudiantes (nombre, apellido, edad, curso_id, created_at, updated_at) 
        VALUES (%(nombre)s, %(apellido)s, %(edad)s, %(curso_id)s, NOW(), NOW());
        """
        return connectToMySQL("esquema_estudiantes_cursos").query_db(query, data)

    @staticmethod
    def obtener_por_curso(curso_id):
        query = """
        SELECT * FROM estudiantes 
        WHERE curso_id = %(curso_id)s;
        """
        data = {"curso_id": curso_id}
        resultados = connectToMySQL("esquema_estudiantes_cursos").query_db(query, data)
        estudiantes = []
        for fila in resultados:
            estudiantes.append({
                "id": fila["id"],
                "nombre": fila["nombre"],
                "apellido": fila["apellido"],
                "edad": fila["edad"],
                "curso_id": fila["curso_id"],
                "created_at": fila["created_at"],
                "updated_at": fila["updated_at"],
            })
        return estudiantes
