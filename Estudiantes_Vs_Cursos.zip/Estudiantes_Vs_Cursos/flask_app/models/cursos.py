from flask_app.config.mysqlconnection import connectToMySQL

class Curso:
    db = "esquema_estudiantes_cursos"

    @classmethod
    def obtener_todos(cls):
        query = "SELECT * FROM cursos;"
        return connectToMySQL(cls.db).query_db(query)

    @classmethod
    def guardar(cls, data):
        query = "INSERT INTO cursos (nombre) VALUES (%(nombre)s);"
        return connectToMySQL(cls.db).query_db(query, data)
