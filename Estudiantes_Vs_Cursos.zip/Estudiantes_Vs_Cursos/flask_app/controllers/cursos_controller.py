
from flask import render_template, redirect, request
from flask_app.models.cursos import Curso
from flask_app.models.estudiantes import Estudiante
from flask_app import app 

@app.route("/cursos/<int:curso_id>")
def ver_curso(curso_id):
    estudiantes = Estudiante.obtener_por_curso(curso_id)
    return render_template("root/cursos.html", estudiantes=estudiantes, curso_id=curso_id)


@app.route("/nuevo_curso", methods=["POST"])
def nuevo_curso():
    data = {"nombre": request.form["nombre"]}
    Curso.guardar(data)
    return redirect("/")
