from flask import redirect, render_template, request, session
from flask_app import app
from flask_app import bcrypt
from flask_app.utils.auth import session_required
from flask import render_template, redirect, request, session
from flask import render_template, redirect, request
from flask_app.models.cursos import Curso
from flask_app.models.estudiantes import Estudiante

@app.route("/")
def index():
    cursos = Curso.obtener_todos()
    return render_template("root/index.html", cursos=cursos)

@app.route("/edit")
def agregar_estudiante():
    cursos = Curso.obtener_todos()  # Obtener todos los cursos para el desplegable
    return render_template("root/edit.html", cursos=cursos)

@app.route("/guardar_estudiante", methods=["POST"])
def guardar_estudiante():
    data = {
        "curso_id": request.form["curso_id"],
        "nombre": request.form["nombre"],
        "apellido": request.form["apellido"],
        "edad": request.form["edad"]
    }
    Estudiante.guardar(data)  # Guardar el estudiante en la base de datos
    return redirect("/edit")  # Redirigir nuevamente a la página edit.html

